from setuptools import setup

setup(
    name = 'Tienda con cliente',
    version= '1.0',
    description= 'Aplicacion para crear clientes',
    author= 'Didier Thomas',
    author_email= 'didierthomas.m@gmail.com',
    packages=['package']
)